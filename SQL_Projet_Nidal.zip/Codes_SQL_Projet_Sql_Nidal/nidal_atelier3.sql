-- Insertion dans la table Auteur
INSERT INTO Auteur (NumAuteur, Nom, Adresse) VALUES
('H', 'Hakim', 'Rue 123'),
('M', 'Moujarrib', 'Rue 456'),
('N', 'Neferiti', 'Rue 789'),
('R', 'Ramsis', 'Rue 101'),
('T', 'Tafih', 'RUE 102');

INSERT INTO Thème (NumThème, IntituléThème) VALUES
('ECO', 'Economie'),
('INFO', 'Informatique'),
('MATH', 'Mathématiques'),
('DIV', 'Divers');

INSERT INTO Editeur (NumEditeur, Nom, Adresse) VALUES
('DAO', 'Dar Al-OuJoum', 'rue abc'),
('NP', 'Nul Part', 'Av DEF'),
('PLB', 'Pour les Bêtes', 'RUE GHI');

INSERT INTO Etudiant (NumEtudiant, Nom, Prénom, Age, Tél, Ville) VALUES
(50, 'Kaslani', 'Kassoul', 28, '065555555', 'Tanger'),
(51, 'Kaslani', 'Kassoula', 27, '065555556', 'Tanger'),
(100, 'Abbassi', 'Abbass', 23, '070000607', 'Tanger'),
(101, 'Kaddouri', 'Kaddour', 24, '077777700', 'Chefchaouen'),
(102, 'Jallouli', 'Jalloul', 23, '066666660', 'Tétouan'),
(103, 'Ayyachi', 'Aicha', 22, NULL, 'Tétouan'),
(113, 'Slaoui', 'Salwa', 21, '060000001', 'Tanger'),
(202, 'Khaldouni', 'Khalid', 22, '060000002', 'Tanger'),
(309, 'Karimi', 'Karim', 20, '066600005', 'Casa'),
(310, 'Karimi', 'Karima', 20, NULL, 'Casa'),
(567, 'Moussaoui', 'Moussa', 21, '050070070', 'Tanger'),
(580, 'Moussi', 'Moussa', 22, NULL, 'Casa'),
(998, 'Moujtahida', 'Moujidda', 21, NULL, 'Tanger'),
(999, 'Moujtahid', 'Moujidd', 21, NULL, 'Tanger');

INSERT INTO Livre (NumLivre, Titre, NumAuteur, NumEditeur, NumThème, DateEdition) VALUES
('BD1', 'Comment avoir 20 en BD', 'R', 'NP', 'INFO', '2015-01-01'),
('BD2', 'Tout sur les BD', 'N', 'NP', 'INFO', '2014-12-01'),
('BD3', 'Maitriser les BD', 'R', 'NP', 'INFO', '2014-07-07'),
('BD4', 'SGBD Relationnels', 'R', 'DAO', 'INFO', '2014-01-01'),
('BD5', 'SI et BD', 'N', 'DAO', 'INFO', '2003-04-02'),
('BD6', 'Les BD : Pour les nuls', 'R', 'NP', 'INFO', '2014-01-01'),
('ECO1', 'économie du Maroc en lan 3050', 'M', 'DAO', 'ECO', '2015-04-01'),
('Math1', 'Algèbre', 'H', 'NP', 'MATH', '2014-09-02'),
('Math2', 'Analyse', 'H', 'NP', 'MATH', '2014-08-02'),
('Math3', 'Algèbre linéaire', 'H', 'DAO', 'MATH', '2015-08-02'),
('Math4', 'Aimer les Maths', 'M', 'NP', 'MATH', '2014-08-04'),
('SE1', 'Systèmes dexploitation', 'R', 'NP', 'INFO', '2003-08-06'),
('SE2', 'Maitriser UNIX', 'R', 'DAO', 'INFO', '2002-10-02'),
('SE3', 'Tout sur les SE', 'N', 'NP', 'INFO', '2001-08-07'),
('TW1','Histoire','T','PLB','DIV',NULL),
('TW2','Personnes fameuses','T','PLB','DIV',NULL),
('TW3','Comment devenir un bon joueur en 5 jours et sans coach','T','PLB','DIV',NULL);

SELECT Nom, Prénom , Age, Ville
FROM Etudiant
WHERE Age > 21
ORDER BY Nom ASC, Age DESC;

INSERT INTO Prêt (NumEtudiant, NumLivre, DatePrêt, Rendu, DateRetour) VALUES
(113, 'BD6', '2015-01-02', FALSE, NULL),
(310, 'BD6', '2014-12-03', FALSE, NULL),   
(998, 'BD6', '2014-08-07', FALSE, NULL); 


SELECT Livre.Titre, Auteur.Nom, Prêt.DatePrêt
FROM Livre
INNER JOIN Auteur ON Livre.NumAuteur = Auteur.NumAuteur
INNER JOIN Prêt ON Livre.NumLivre = Prêt.NumLivre
WHERE Prêt.Rendu = FALSE;

CREATE TABLE Professeur (
    CIN NUMERIC PRIMARY KEY,
    Nom VARCHAR(20) NOT NULL,
    Prénom VARCHAR(20) NOT NULL,
    Adresse TEXT
);

ALTER TABLE Professeur
ADD CONSTRAINT uq_NomPrenom UNIQUE (Nom, Prénom);

ALTER TABLE Professeur
ADD COLUMN Email VARCHAR(10);

ALTER TABLE Professeur
MODIFY COLUMN Email  VARCHAR(50);

ALTER TABLE Professeur
DROP COLUMN Email;

DROP TABLE Professeur;

INSERT INTO Etudiant (NumEtudiant, Nom, Prénom, Age, Tél, Ville) VALUES
(1001, 'Hammadi', 'Hamada', 25, 061111111, 'Casa'),
(1002, 'Tahiri', 'Tahir', 24, 066666600, 'Tanger');

INSERT INTO Etudiant (NumEtudiant, Nom, Prénom, Age, Ville) VALUES
(1003, 'Sallami', 'Salma', 26, 'Tanger'),
(1004, 'Mimouni', 'Mimoun', 23, 'Casa');

UPDATE Etudiant
SET Ville = 'Casablanca'
WHERE Ville = 'Casa';

UPDATE Etudiant
SET Age = Age + 1
WHERE NumEtudiant > 1000;

DELETE FROM Etudiant
WHERE NumEtudiant > 1000;


-- Interrogation des données

-- 7. Nom, prénom et adresse de l'étudiant Moujtahid

SELECT Nom, Prénom,ville
FROM Etudiant
WHERE Nom = 'Moujtahid';

-- Liste des livres de l'auteur numéro 'R'
SELECT Titre
FROM Livre
WHERE NumAuteur = 'R';

-- 9. Livres de l'auteur de nom 'Ramsis'
SELECT l.Titre
FROM Livre l
JOIN Auteur a ON l.NumAuteur = a.NumAuteur
WHERE a.Nom = 'Ramsis';

-- 10. Numéro de l'auteur du livre 'Comment avoir 20 en BD'
SELECT NumAuteur
FROM Livre
WHERE Titre = 'Comment avoir 20 en BD';

-- 11. Nom et adresse de l'auteur du livre 'Comment avoir 20 en BD'
SELECT a.Nom, a.Adresse
FROM Auteur a
JOIN Livre l ON a.NumAuteur = l.NumAuteur
WHERE l.Titre = 'Comment avoir 20 en BD';

-- 12. Les livres de l'auteur Ramsis édités chez l'éditeur Nulle part
SELECT l.Titre
FROM Livre l
JOIN Auteur a ON l.NumAuteur = a.NumAuteur
JOIN Editeur e ON l.NumEditeur = e.NumEditeur
WHERE a.Nom = 'Ramsis' AND e.Nom = 'Nul Part';

-- 13. Livres de l'auteur Ramsis ou Nefertiti
SELECT l.Titre
FROM Livre l
JOIN Auteur a ON l.NumAuteur = a.NumAuteur
WHERE a.Nom IN ('Ramsis', 'Nefertiti');

-- 14. Thèmes des livres édités chez Nul Part
SELECT DISTINCT t.IntituléThème
FROM Livre l
JOIN  Thème t ON l.NumThème = t.NumThème
JOIN Editeur e ON l.NumEditeur = e.NumEditeur
WHERE l.NumEditeur = 'Nul Part';

-- 15. Thèmes des livres dans la bibliothèque par éditeur
SELECT e.Nom AS Editeur, t.IntituléThème
FROM Livre l
JOIN Editeur e ON l.NumEditeur = e.NumEditeur
JOIN Thème t ON l.NumThème = t.NumThème;

-- 16. Livres de l'auteur Ramsis édités chez Nul Part et empruntés par l'étudiant Moujtahid
SELECT l.Titre, e.Nom, p.DatePrêt
FROM Livre l
JOIN Auteur a ON l.NumAuteur = a.NumAuteur
JOIN Editeur e ON l.NumEditeur = e.NumEditeur
JOIN Prêt p ON l.NumLivre = p.NumLivre
JOIN Etudiant et ON p.NumEtudiant = et.NumEtudiant
WHERE a.Nom = 'Ramsis' AND e.Nom = 'Nul Part' AND et.Nom = 'Moujtahid';



-- 17. Livres qui n'ont jamais été empruntés
SELECT l.Titre
FROM Livre l
LEFT JOIN Prêt p ON l.NumLivre = p.NumLivre
WHERE p.NumLivre IS NULL;

-- 18. Livres de l'auteur Ramsis qui n'ont jamais été empruntés
SELECT l.Titre
FROM Livre l
JOIN Auteur a ON l.NumAuteur = a.NumAuteur
LEFT JOIN Prêt p ON l.NumLivre = p.NumLivre
WHERE a.Nom = 'Ramsis' AND p.NumLivre IS NULL;


-- 19. Liste des livres empruntés par Moujtahid et leurs thèmes
SELECT l.Titre, t.IntituléThème
FROM Livre l
JOIN Prêt p ON l.NumLivre = p.NumLivre
JOIN Etudiant e ON p.NumEtudiant = e.NumEtudiant
JOIN Thème t ON l.NumThème = t.NumThème
WHERE e.Nom = 'Moujtahid';


-- 20. Liste des livres empruntés par Moujtahid, leurs thèmes et les noms des éditeurs
SELECT l.Titre, t.IntituléThème, e.Nom
FROM Livre l
JOIN Thème t ON l.NumThème = t.NumThème
JOIN Editeur e ON l.NumEditeur = e.NumEditeur
JOIN Prêt p ON l.NumLivre = p.NumLivre
JOIN Etudiant et ON p.NumEtudiant = et.NumEtudiant
WHERE et.Nom = 'Moujtahid';

-- 21. Thèmes qui n'ont jamais été empruntés par l'étudiant 999
SELECT t.IntituléThème
FROM Thème t
LEFT JOIN Livre l ON t.NumThème = l.NumThème
LEFT JOIN Prêt p ON l.NumLivre = p.NumLivre AND p.NumEtudiant = 999
WHERE p.NumLivre IS NULL;


-- 22. Livres empruntés par l'étudiant 'Kaslani' et leurs dates de prêt
SELECT l.Titre, p.DatePrêt
FROM Livre l
JOIN Prêt p ON l.NumLivre = p.NumLivre
JOIN Etudiant e ON p.NumEtudiant = e.NumEtudiant
WHERE e.Nom = 'Kaslani';

-- 23. Titre et emprunteur du livre non rendu avec la date de prêt la plus ancienne
SELECT l.Titre, e.Nom AS Emprunteur, MIN(p.DatePrêt) AS DatePrêt
FROM Livre l
JOIN Prêt p ON l.NumLivre = p.NumLivre
JOIN Etudiant e ON p.NumEtudiant = e.NumEtudiant
WHERE p.DateRetour IS NULL
GROUP BY l.Titre, e.Nom
ORDER BY MIN(p.DatePrêt) ASC
LIMIT 1;

-- 24. Liste de tous les livres avec nom de l'auteur, éditeur et thème
SELECT l.Titre, a.Nom AS Auteur, ed.Nom AS Editeur, t.IntituléThème
FROM Livre l
JOIN Auteur a ON l.NumAuteur = a.NumAuteur
JOIN Editeur ed ON l.NumEditeur = ed.NumEditeur
JOIN Thème t ON l.NumThème = t.NumThème;


-- 25. Titres des livres empruntés entre 01/01/2015 et 31/05/2015
SELECT DISTINCT l.Titre
FROM Livre l
JOIN Prêt p ON l.NumLivre = p.NumLivre
WHERE p.DatePrêt BETWEEN '2015-01-01' AND '2015-05-31';

-- 26. Tous les titres qui contiennent le mot "BD"
SELECT Titre
FROM Livre
WHERE Titre LIKE '%BD%';

-- Group By

-- 27. Nombre de livres écrits par chaque auteur
SELECT a.Nom AS Auteur, COUNT(*) AS NombreLivres
FROM Livre l
JOIN Auteur a ON l.NumAuteur = a.NumAuteur
GROUP BY a.Nom;

-- 28. Âge moyen des étudiants par ville
SELECT Ville, AVG(Age) AS AgeMoyen
FROM Etudiant
GROUP BY Ville;

 
-- 29. Nombre total de fois qu'un livre a été emprunté (pour les livres empruntés plus de 3 fois)
SELECT p.NumLivre, COUNT(*) AS TotalEmprunts
FROM Prêt p
GROUP BY p.NumLivre
HAVING COUNT(*) > 3;

-- 30. Nombre total de fois qu'un livre non rendu a été emprunté (pour les livres empruntés plus de 3 fois)
SELECT p.NumLivre, COUNT(*) AS TotalEmpruntsNonRendus
FROM Prêt p
WHERE p.DateRetour IS NULL
GROUP BY p.NumLivre
HAVING COUNT(*) > 3;

-- 31. Livres de l'auteur Ramsis empruntés plus de 4 fois
SELECT l.Titre
FROM Livre l
JOIN Auteur a ON l.NumAuteur = a.NumAuteur
JOIN Prêt p ON l.NumLivre = p.NumLivre
WHERE a.Nom = 'Ramsis'
GROUP BY l.Titre
HAVING COUNT(*) > 4;

-- 32. Étudiants âgés de moins de 23 ans ayant emprunté plus de 3 livres différents en 2015
SELECT e.Nom AS Etudiant, e.Age, COUNT(DISTINCT p.NumLivre) AS LivresEmpruntes
FROM Etudiant e
JOIN Prêt p ON e.NumEtudiant = p.NumEtudiant
WHERE e.Age < 23 AND EXTRACT(YEAR FROM p.DatePrêt) = 2015
GROUP BY e.Nom, e.Age
HAVING COUNT(DISTINCT p.NumLivre) > 3;