-- Création de la base de données
CREATE DATABASE Biblio_Nidal;

 -- Création de la table Etudiant
CREATE TABLE Etudiant (  
  NumEtudiant INT PRIMARY KEY,  
  Nom VARCHAR(30) NOT NULL,  
  Prénom VARCHAR(30) NOT NULL,  
  Age INT CHECK (Age BETWEEN 15 AND 30),  
  Ville VARCHAR(30) ,  
  Tél VARCHAR(20)  
);  


-- Modification du champ Ville avec SQL
ALTER TABLE Etudiant MODIFY COLUMN Ville VARCHAR(30) NOT NULL;

-- En MySQL, la commande ALTER TABLE permet de modifier la structure d’une table, mais la manière dont on change les colonnes (notamment les types de données ou les contraintes) a une syntaxe spécifique.
	-- •	Dans MySQL, pour modifier le type de la colonne, on utilise MODIFY COLUMN.
	-- •	Dans PostgreSQL et SQL Server, on peut parfois utiliser ALTER COLUMN avec des sous-commandes comme TYPE ou SET. --

CREATE TABLE Livre (  
    NumLivre VARCHAR(10) PRIMARY KEY,  
    Titre VARCHAR(50) NOT NULL,  
    NumAuteur VARCHAR(10),  
    NumEditeur VARCHAR(10),  
    NumThème VARCHAR(10),  
    DateEdition DATE NOT NULL
);  

-- Création de la table Auteur  
CREATE TABLE Auteur (  
    NumAuteur VARCHAR(10) PRIMARY KEY,  
    Nom VARCHAR(30) NOT NULL,  
    Adresse VARCHAR(50)  
);  
-- Création de la table Editeur  
CREATE TABLE Editeur (  
    NumEditeur VARCHAR(10) PRIMARY KEY,  
    Nom VARCHAR(30) NOT NULL,  
    Adresse VARCHAR(50)  
);  

-- Ajout de la contrainte d'intégrité référentielle entre Livre et Auteur
ALTER TABLE Livre 
ADD CONSTRAINT fk_Auteur FOREIGN KEY (NumAuteur) 
REFERENCES Auteur(NumAuteur) 
ON UPDATE CASCADE 
ON DELETE CASCADE;

INSERT INTO Auteur (NumAuteur, Nom, Adresse)
VALUES ('AT1', 'Auteur1', 'Rue 1');

INSERT INTO Editeur (NumEditeur, Nom, Adresse)
VALUES ('Edit1', 'editeur1', 'Rue Edition');

INSERT INTO Livre (NumLivre, Titre, NumAuteur, NumEditeur, NumThème, DateEdition)
VALUES ('numLivre1', 'TitreLivre 1', 'AT1', 'Edit1', 'T1heme', '2023-02-01');

UPDATE Auteur
SET NumAuteur = 'AUT1'
WHERE NumAuteur = 'AUT1';

UPDATE Editeur
SET NumEditeur = 'Edit1' 
WHERE NumEditeur='EDT1';

select * from Auteur;
select * from Editeur;

DELETE   FROM Editeur;
DELETE  FROM Auteur;


CREATE TABLE Thème (
    NumThème VARCHAR(10) PRIMARY KEY,
    IntituléThème VARCHAR(20) NOT NULL
);

-- Ajout de la relation entre Livre et Thème et application de la contrainte d'intégrité

ALTER TABLE Livre
ADD CONSTRAINT fk_Thème FOREIGN KEY (NumThème)
REFERENCES Thème(NumThème);

-- Création de la table Prêt
CREATE TABLE Prêt (
    NumEtudiant NUMERIC(10),
    NumLivre VARCHAR(10),
    DatePrêt DATE,
    Rendu BOOLEAN DEFAULT FALSE,
    DateRetour DATE,
    PRIMARY KEY (NumEtudiant, NumLivre, DatePrêt),
    FOREIGN KEY (NumEtudiant) REFERENCES Etudiant(NumEtudiant),
    FOREIGN KEY (NumLivre) REFERENCES Livre(NumLivre),
    CONSTRAINT uq_Pret UNIQUE (NumLivre, Rendu, DateRetour)
);
 ALTER TABLE Etudiant
ADD CONSTRAINT check_age CHECK (Age BETWEEN 15 AND 30);  

ALTER TABLE Prêt
ADD CONSTRAINT check_dateRetour CHECK (DateRetour IS NULL OR (DateRetour >= DatePrêt AND Rendu = TRUE));
