CREATE DATABASE Tp_BD_Nidal;
USE  Tp_bd_nidal;

CREATE TABLE Employes (
    NumEmploye INT  PRIMARY KEY,
    Nom VARCHAR(30),
    Prenom VARCHAR(30),
    Tel VARCHAR(20)
);

-- Insertion de données dans la table employés
INSERT INTO employes (Nom, Prenom, Tel) VALUES
	('El Abbadi', 'Zakaria', '0600000000'),
    ('Benali ', 'Yassine', '0700000000'), 
    ('Eyoub', 'Nidal', '00800000');

SELECT * FROM employes;

    
CREATE TABLE Clients (
    RefClient VARCHAR(10) PRIMARY KEY,
    NomSociete VARCHAR(50),
    Ville VARCHAR(50),
    codepostale VARCHAR(10)
);

ALTER TABLE Employes
RENAME COLUMN codepostale TO CP;

-- Insertion des Données dans Clients

INSERT INTO Clients (RefClient, NomSociete, Ville, CP) 
VALUES 
('C1', 'Acom', 'Tanger', '9000'),
('C2', 'B2C', 'Casa', '40000'),
('C3', 'Tcom', 'Rabat', '40000');

INSERT INTO Clients (RefClient, NomSociete, Ville, CP) VALUES
('C1', 'Jim', 'Meknès', '50000');



CREATE TABLE Commandes (  
  RéfCom INT PRIMARY KEY AUTO_INCREMENT,  
  Société VARCHAR(50),  
  Date DATE,  
  Somme DECIMAL(10,2),  
  TVA DECIMAL(10,2)  
);  


ALTER TABLE Commandes  
ADD COLUMN RefClient VARCHAR(10),  
ADD FOREIGN KEY (RefClient) REFERENCES Clients(RefClient) ;


DESCRIBE commandes;


SELECT c.RefClient, c.NomSociete, c.Ville, co.RéfCom, co.Date 
FROM Clients c
LEFT JOIN Commandes co ON c.RefClient = co.RefClient;


-- Sélectionner tous les Commandes.
SELECT * FROM Commandes;

-- Sélectionner tous les clients.
SELECT * FROM clients;

